### target java version
java 1.8

### Entry point
/src/main/java/test/Program.java

### Input commands
/src/main/resources/input.txt

### Output
will be printed in console.
