package beans;

public enum LectorType {
    ASSISTANT,
    DOCENT,
    PROFESSOR
}
